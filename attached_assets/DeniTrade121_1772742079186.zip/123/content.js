// Deni Trade Overlay - Browser Extension v6
let wins = 0;
let losses = 0;
let overlayScale = 1;

const overlay123_unique = document.createElement("div");
overlay123_unique.id = "deni-overlay123_unique";
overlay123_unique.innerHTML = `
  <canvas id="deni-fire-canvas"></canvas>
  <div id="deni-content">
    <div id="deni-score">
      <div id="deni-win-block">
        <span id="wins-display">+0</span>
      </div>
      <div id="deni-divider"></div>
      <div id="deni-loss-block">
        <span id="losses-display">-0</span>
      </div>
    </div>
    <div id="deni-buttons">
      <button id="btn-plus">+</button>
      <button id="btn-reset">\u0421\u0431\u0440\u043E\u0441</button>
      <button id="btn-minus">&minus;</button>
    </div>
    <div id="deni-brand">DENI TRADE</div>
  </div>
  <div id="deni-resize-handle"></div>
`;

if (!document.querySelector("style[data-deni-v6]")) {
  const s = document.createElement("style");
  s.setAttribute("data-deni-v6", "true");
  s.textContent = `
    #deni-overlay123_unique, #deni-overlay123_unique * { box-sizing: border-box; margin: 0; padding: 0; }
  `;
  document.head.appendChild(s);
}

overlay123_unique.style.cssText = `
  position: fixed;
  top: 100px;
  left: 50%;
  width: 240px;
  z-index: 999999;
  cursor: move;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
  font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Arial, sans-serif;
  border-radius: 18px;
  overflow: visible;
  background: linear-gradient(
    145deg,
    rgba(42, 44, 48, 0.94) 0%,
    rgba(38, 40, 44, 0.93) 50%,
    rgba(34, 36, 40, 0.95) 100%
  );
  box-shadow:
    0 8px 32px rgba(0, 0, 0, 0.35),
    0 2px 8px rgba(0, 0, 0, 0.18),
    inset 0 1px 0 rgba(255, 255, 255, 0.04),
    inset 0 0 0 1px rgba(255, 255, 255, 0.02);
  -webkit-mask-image: radial-gradient(
    ellipse 88% 88% at 50% 50%,
    black 50%,
    rgba(0,0,0,0.7) 70%,
    rgba(0,0,0,0.25) 85%,
    transparent 100%
  );
  mask-image: radial-gradient(
    ellipse 88% 88% at 50% 50%,
    black 50%,
    rgba(0,0,0,0.7) 70%,
    rgba(0,0,0,0.25) 85%,
    transparent 100%
  );
`;

const fireCanvas = overlay123_unique.querySelector("#deni-fire-canvas");
fireCanvas.style.cssText = `
  position: absolute;
  top: 0; left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
  border-radius: 18px;
`;

const contentDiv = overlay123_unique.querySelector("#deni-content");
contentDiv.style.cssText = `
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 22px 18px 14px;
`;

const scoreDiv = overlay123_unique.querySelector("#deni-score");
scoreDiv.style.cssText = `
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  margin-bottom: 18px;
  width: 100%;
`;

const winBlock = overlay123_unique.querySelector("#deni-win-block");
winBlock.style.cssText = `display: flex; flex-direction: column; align-items: center;`;

const winsSpan = overlay123_unique.querySelector("#wins-display");
winsSpan.style.cssText = `
  font-size: 36px;
  font-weight: 700;
  color: rgba(120, 220, 160, 0.75);
  letter-spacing: -1px;
`;

const divider = overlay123_unique.querySelector("#deni-divider");
divider.style.cssText = `
  width: 1px;
  height: 36px;
  background: linear-gradient(180deg, transparent, rgba(255,255,255,0.1), transparent);
`;

const lossBlock = overlay123_unique.querySelector("#deni-loss-block");
lossBlock.style.cssText = `display: flex; flex-direction: column; align-items: center;`;

const lossesSpan = overlay123_unique.querySelector("#losses-display");
lossesSpan.style.cssText = `
  font-size: 36px;
  font-weight: 700;
  color: rgba(235, 120, 120, 0.7);
  letter-spacing: -1px;
`;

const buttonsDiv = overlay123_unique.querySelector("#deni-buttons");
buttonsDiv.style.cssText = `
  display: flex;
  gap: 6px;
  width: 100%;
  margin-bottom: 14px;
`;

const btnBase = `
  flex: 1;
  height: 34px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-family: inherit;
  transition: all 0.15s ease;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const plusBtn = overlay123_unique.querySelector("#btn-plus");
plusBtn.style.cssText = `
  ${btnBase}
  font-size: 16px;
  border: 1px solid rgba(120, 220, 160, 0.15);
  background: rgba(120, 220, 160, 0.08);
  color: rgba(120, 220, 160, 0.8);
`;

const resetBtn = overlay123_unique.querySelector("#btn-reset");
resetBtn.style.cssText = `
  ${btnBase}
  font-size: 10px;
  border: 1px solid rgba(255, 255, 255, 0.06);
  background: rgba(255, 255, 255, 0.04);
  color: rgba(255, 255, 255, 0.35);
  letter-spacing: 1.5px;
`;

const minusBtn = overlay123_unique.querySelector("#btn-minus");
minusBtn.style.cssText = `
  ${btnBase}
  font-size: 16px;
  border: 1px solid rgba(235, 120, 120, 0.12);
  background: rgba(235, 120, 120, 0.07);
  color: rgba(235, 120, 120, 0.75);
`;

const brandDiv = overlay123_unique.querySelector("#deni-brand");
brandDiv.style.cssText = `
  font-size: 11px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.18);
  letter-spacing: 5px;
  text-transform: uppercase;
`;

// Resize handle
const resizeHandle = overlay123_unique.querySelector("#deni-resize-handle");
resizeHandle.style.cssText = `
  position: absolute;
  bottom: 2px;
  right: 2px;
  width: 16px;
  height: 16px;
  cursor: nwse-resize;
  z-index: 10;
  background: transparent;
`;
const resizeSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
resizeSvg.setAttribute("width", "12");
resizeSvg.setAttribute("height", "12");
resizeSvg.setAttribute("viewBox", "0 0 12 12");
resizeSvg.style.cssText = "position:absolute;bottom:2px;right:2px;pointer-events:none;opacity:0.15;";
resizeSvg.innerHTML = `<line x1="10" y1="2" x2="2" y2="10" stroke="white" stroke-width="1"/><line x1="10" y1="6" x2="6" y2="10" stroke="white" stroke-width="1"/>`;
resizeHandle.appendChild(resizeSvg);

// Button hover effects
[plusBtn, resetBtn, minusBtn].forEach(btn => {
  btn.addEventListener("mouseover", () => { btn.style.filter = "brightness(1.4)"; });
  btn.addEventListener("mouseout", () => { btn.style.filter = "brightness(1)"; });
  btn.addEventListener("mousedown", () => { btn.style.transform = "scale(0.96)"; });
  btn.addEventListener("mouseup", () => { btn.style.transform = "scale(1)"; });
});

plusBtn.addEventListener("click", (e) => { e.stopPropagation(); wins++; updateDisplay(); saveState(); });
minusBtn.addEventListener("click", (e) => { e.stopPropagation(); losses++; updateDisplay(); saveState(); });
resetBtn.addEventListener("click", (e) => { e.stopPropagation(); wins = 0; losses = 0; updateDisplay(); saveState(); });

function updateDisplay() {
  winsSpan.textContent = "+" + wins;
  lossesSpan.textContent = "-" + losses;
}

function saveState() {
  localStorage.setItem("deni-overlay123_unique-state", JSON.stringify({ wins, losses, scale: overlayScale }));
}

function loadState() {
  const saved = localStorage.getItem("deni-overlay123_unique-state");
  if (saved) {
    const state = JSON.parse(saved);
    wins = state.wins || 0;
    losses = state.losses || 0;
    overlayScale = state.scale || 1;
    updateDisplay();
    applyScale();
  }
}

function applyScale() {
  overlay123_unique.style.transform = `scale(${overlayScale})`;
  overlay123_unique.style.transformOrigin = "top left";
}

// Organic ambient animation - soft waves and gentle particles
function initFire() {
  const c = fireCanvas;
  const ctx = c.getContext("2d");
  if (!ctx) return;

  let particles = [];
  let waves = [];
  const MAX_PARTICLES = 18;
  const MAX_WAVES = 2;

  function resize() {
    const w = overlay123_unique.offsetWidth;
    const h = overlay123_unique.offsetHeight;
    c.width = w * 2;
    c.height = h * 2;
    c.style.width = w + "px";
    c.style.height = h + "px";
    ctx.setTransform(2, 0, 0, 2, 0, 0);
  }
  resize();

  class Particle {
    constructor() { this.reset(); }
    reset() {
      const w = c.width / 2;
      const h = c.height / 2;
      
      this.x = Math.random() * w;
      this.y = Math.random() * h;
      this.baseX = this.x;
      this.baseY = this.y;
      
      this.size = 1.2 + Math.random() * 1.8;
      this.angle = Math.random() * Math.PI * 2;
      this.orbitRadius = 15 + Math.random() * 25;
      this.orbitSpeed = 0.008 + Math.random() * 0.012;
      
      this.opacity = 0;
      this.maxOpacity = 0.12 + Math.random() * 0.18;
      this.life = 0;
      this.maxLife = 400 + Math.random() * 600;
      
      this.breathSpeed = 0.015 + Math.random() * 0.01;
      this.breathOffset = Math.random() * Math.PI * 2;
    }
    
    update() {
      this.life++;
      
      this.angle += this.orbitSpeed;
      this.x = this.baseX + Math.cos(this.angle) * this.orbitRadius;
      this.y = this.baseY + Math.sin(this.angle) * this.orbitRadius;
      
      const breath = Math.sin(this.life * this.breathSpeed + this.breathOffset);
      this.currentSize = this.size * (0.85 + breath * 0.15);
      
      const fadeIn = 80;
      const fadeOut = 120;
      if (this.life < fadeIn) {
        this.opacity = this.maxOpacity * (this.life / fadeIn);
      } else if (this.life > this.maxLife - fadeOut) {
        this.opacity = this.maxOpacity * ((this.maxLife - this.life) / fadeOut);
      } else {
        this.opacity = this.maxOpacity + Math.sin(this.life * this.breathSpeed) * 0.03;
      }
      
      if (this.life >= this.maxLife) this.reset();
    }
    
    draw() {
      const blur = this.currentSize * 3.5;
      const glow = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, blur);
      glow.addColorStop(0, `rgba(180, 180, 185, ${this.opacity * 0.5})`);
      glow.addColorStop(0.4, `rgba(160, 160, 165, ${this.opacity * 0.25})`);
      glow.addColorStop(1, `rgba(140, 140, 145, 0)`);
      
      ctx.beginPath();
      ctx.arc(this.x, this.y, blur, 0, Math.PI * 2);
      ctx.fillStyle = glow;
      ctx.fill();
    }
  }

  class Wave {
    constructor(index) { 
      this.index = index;
      this.reset(); 
    }
    reset() {
      const w = c.width / 2;
      const h = c.height / 2;
      
      this.points = [];
      this.numPoints = 8;
      this.baseY = h * 0.3 + (this.index * h * 0.2);
      
      for (let i = 0; i < this.numPoints; i++) {
        this.points.push({
          x: (w / (this.numPoints - 1)) * i,
          offset: Math.random() * Math.PI * 2,
          speed: 0.008 + Math.random() * 0.008,
          amplitude: 12 + Math.random() * 18
        });
      }
      
      this.opacity = 0.06 + Math.random() * 0.08;
      this.life = 0;
    }
    
    update() {
      this.life++;
      this.points.forEach(p => {
        p.offset += p.speed;
      });
    }
    
    draw() {
      const w = c.width / 2;
      
      ctx.beginPath();
      ctx.moveTo(0, this.baseY);
      
      for (let i = 0; i < this.points.length; i++) {
        const p = this.points[i];
        const y = this.baseY + Math.sin(this.life * p.speed + p.offset) * p.amplitude;
        
        if (i === 0) {
          ctx.lineTo(p.x, y);
        } else {
          const prevP = this.points[i - 1];
          const prevY = this.baseY + Math.sin(this.life * prevP.speed + prevP.offset) * prevP.amplitude;
          
          const cpX = (prevP.x + p.x) / 2;
          const cpY = (prevY + y) / 2;
          
          ctx.quadraticCurveTo(prevP.x, prevY, cpX, cpY);
          if (i === this.points.length - 1) {
            ctx.lineTo(p.x, y);
          }
        }
      }
      
      ctx.strokeStyle = `rgba(140, 145, 150, ${this.opacity})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      
      ctx.strokeStyle = `rgba(160, 165, 170, ${this.opacity * 0.4})`;
      ctx.lineWidth = 0.8;
      ctx.stroke();
    }
  }

  // Initialize
  for (let i = 0; i < MAX_PARTICLES; i++) {
    const p = new Particle();
    p.life = Math.floor(Math.random() * p.maxLife);
    particles.push(p);
  }
  
  for (let i = 0; i < MAX_WAVES; i++) {
    waves.push(new Wave(i));
  }

  let frameCount = 0;

  function animate() {
    const w = c.width / 2;
    const h = c.height / 2;
    
    ctx.clearRect(0, 0, w, h);
    
    frameCount++;
    
    // Subtle vignette
    const vignette = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) * 0.8);
    vignette.addColorStop(0, "rgba(0, 0, 0, 0)");
    vignette.addColorStop(0.7, "rgba(0, 0, 0, 0.02)");
    vignette.addColorStop(1, "rgba(0, 0, 0, 0.08)");
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, w, h);

    waves.forEach(w => { w.update(); w.draw(); });
    particles.forEach(p => { p.update(); p.draw(); });
    
    requestAnimationFrame(animate);
  }
  animate();

  new ResizeObserver(() => resize()).observe(overlay123_unique);
}

// Drag
let isDragging = false;
let startX = 0, startY = 0, initialLeft = 0, initialTop = 0;

overlay123_unique.addEventListener("mousedown", (e) => {
  if (e.button !== 0) return;
  if ([plusBtn, minusBtn, resetBtn].includes(e.target)) return;
  if (e.target === resizeHandle || resizeHandle.contains(e.target)) return;
  isDragging = true;
  startX = e.clientX;
  startY = e.clientY;
  const st = window.getComputedStyle(overlay123_unique);
  initialLeft = parseFloat(st.left);
  initialTop = parseFloat(st.top);
  overlay123_unique.style.cursor = "grabbing";
});

document.addEventListener("mousemove", (e) => {
  if (!isDragging) return;
  e.preventDefault();
  overlay123_unique.style.left = (initialLeft + e.clientX - startX) + "px";
  overlay123_unique.style.top = (initialTop + e.clientY - startY) + "px";
});

document.addEventListener("mouseup", () => {
  if (isDragging) { isDragging = false; overlay123_unique.style.cursor = "move"; }
});

// Resize via handle
let isResizing = false;
let resizeStartX = 0;
let resizeStartScale = 1;

resizeHandle.addEventListener("mousedown", (e) => {
  e.stopPropagation();
  e.preventDefault();
  isResizing = true;
  resizeStartX = e.clientX;
  resizeStartScale = overlayScale;
});

document.addEventListener("mousemove", (e) => {
  if (!isResizing) return;
  e.preventDefault();
  const dx = e.clientX - resizeStartX;
  overlayScale = Math.max(0.5, Math.min(2.5, resizeStartScale + dx / 200));
  applyScale();
});

document.addEventListener("mouseup", () => {
  if (isResizing) { isResizing = false; saveState(); }
});

loadState();
document.body.appendChild(overlay123_unique);
setTimeout(initFire, 100);
